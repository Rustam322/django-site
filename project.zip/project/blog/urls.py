from django.urls import path
from .views import *
urlpatterns = [
    # path('', index, name='index'),
    # path('category/<int:category_id>/', category_page, name='category'),
    # path('article/<int:article_id>', article_detail, name='article'),
    # path('add/', add_article, name='add')
    path('', ArticleList.as_view(), name='index'),
    path('category/<int:category_id>/', ArticleListByCategory.as_view(), name='category'),
    path('article/<int:pk>', ArticleDetail.as_view(), name='article'),
    path('add/', NewArticle.as_view(), name='add'),
    path('article/<int:pk>/update/', ArticleUpdate.as_view(), name='article_update'),
    path('article/<int:pk>/delete/', ArticleDelete.as_view(), name='article_delete'),
    path('login/', user_login, name='login'),
    path('logout/', user_logout, name='logout'),
    path('register', register, name='register'),
    path('search/', SearchResults.as_view(), name='search'),
    path('add_comment/<int:pk>/', save_comment, name='save_comment'),
    path('profile/<int:user_id>', profile, name='profile'),
    path('edit_profile/', edit_profile, name='edit_profile'),
    path('add_or_delete_mark/<int:article_id>/<str:action>/', add_or_delete_mark, name='mark')
]
