from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.contrib.auth import login, logout
from .models import Category, Article, Comment, Profile, Like
from .forms import ArticleForm, LoginForm, RegistrationForm, CommentForm, EditUserForm, EditProfileForm
from django.contrib import messages
from django.views.generic import ListView, DetailView, CreateView, DeleteView, UpdateView
from django.db.models import Q



# Create your views here.

# def index(request):
#     print(request.GET)
#     articles = Article.objects.all()
#     sort_field = request.GET.get('sort')
#     if sort_field:
#         articles = articles.order_by(sort_field)
#
#     context = {
#         'title': 'Главная страница PROWEB-блог',
#         'articles': articles
#     }
#     return render(request, 'blog/index.html', context)


class ArticleList(ListView):  # article_list.html
    model = Article  # Что вытаскивать берет ВСЕ объекты модели
    context_object_name = 'articles'  # Под каким именем отправить
    template_name = 'blog/index.html'
    extra_context = {
        'title': 'Главная страница PROWEB-блог 2'
    }

    def get_queryset(self):
        articles = Article.objects.all()
        sort_field = self.request.GET.get('sort')
        if sort_field:
            articles = articles.order_by(sort_field)
        return articles


# def category_page(request, category_id):
#     articles = Article.objects.filter(category_id=category_id)
#     category = Category.objects.get(pk=category_id)
#     sort_field = request.GET.get('sort')
#     if sort_field:
#         articles = articles.order_by(sort_field)
#     context = {
#         'title': f'Категория: {category.title}',
#         'articles': articles
#     }
#     return render(request, 'blog/index.html', context)


class ArticleListByCategory(ArticleList):
    def get_queryset(self):
        articles = Article.objects.filter(category_id=self.kwargs['category_id'])
        print(articles)
        sort_field = self.request.GET.get('sort')
        if sort_field:
            articles = articles.order_by(sort_field)
        return articles

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data()
        category = Category.objects.get(pk=self.kwargs['category_id'])
        context['title'] = f'Стать категории "{category.title}"'
        return context


# def article_detail(request, article_id):
#     article = Article.objects.get(pk=article_id)
#     article.views += 1
#     article.save()
#
#     articles = Article.objects.all()
#     articles = articles.order_by('-views')
#
#     context = {
#         'article': article,
#         'articles': articles[:4]
#     }
#     return render(request, 'blog/article_detail.html', context)


class ArticleDetail(LoginRequiredMixin, DetailView):  # article_detail.html
    model = Article
    login_url = 'login'

    def get_queryset(self):
        return Article.objects.filter(pk=self.kwargs['pk'])

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        article = Article.objects.get(pk=self.kwargs['pk'])
        article.views += 1
        article.save()
        user = self.request.user
        if user.is_authenticated:
            mark, created = Like.objects.get_or_create(user=user, article=article)
            if created:
                context['like'] = False
                context['dislike'] = False
            else:
                context['like'] = mark.like
                context['dislike'] = mark.dislike
        else:
            context['like'] = False
            context['dislike'] = False
        likes = Like.objects.filter(article=article)
        likes_count = len([i for i in likes if i.like])
        dislikes_count = len([i for i in likes if i.dislike])
        context['likes_count'] = likes_count
        context['dislikes_count'] = dislikes_count

        context['title'] = f'Статья на тему: {article.title}'
        articles = Article.objects.all()
        articles = articles.order_by('-views')
        context['articles'] = articles[:4]
        if self.request.user.is_authenticated:
            context['comment_form'] = CommentForm()
        context['comments'] = Comment.objects.filter(article=article)

        return context


# def add_article(request):
#     if request.method == 'POST':
#         form = ArticleForm(request.POST, request.FILES)
#         if form.is_valid():
#             article = Article.objects.create(**form.cleaned_data)
#             article.save()
#             return redirect('article', article.pk)
#     else:
#         form = ArticleForm()
#
#     context = {
#         'form': form,
#         'title': 'Добавить статью'
#     }
#     return render(request, 'blog/article_form.html', context)


class NewArticle(CreateView):
    form_class = ArticleForm
    template_name = 'blog/article_form.html'
    extra_context = {
        'title': 'Добавить новую статью'
    }


class ArticleUpdate(UpdateView):
    model = Article
    form_class = ArticleForm
    template_name = 'blog/article_form.html'


class ArticleDelete(DeleteView):
    model = Article
    success_url = reverse_lazy('index')
    context_object_name = 'article'


def user_login(request):
    if request.method == 'POST':
        form = LoginForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            if user:
                login(request, user)
                messages.success(request, 'Вы успешно авторизовались!')
                return redirect('index')
            else:
                messages.error(request, 'Не верное имя пользователя/пароль')
                return redirect('login')
        else:
            messages.error(request, 'Не верное имя пользователя/пароль')
            return redirect('login')
    else:
        form = LoginForm()
    context = {
        'title': 'Авторизация',
        'form': form
    }
    return render(request, 'blog/user_login.html', context)


def user_logout(request):
    logout(request)
    messages.warning(request, 'Вы вышли из аккаунта')
    return redirect('index')


def register(request):
    if request.method == 'POST':
        form = RegistrationForm(data=request.POST)
        if form.is_valid():
            user = form.save()
            profile_user = Profile.objects.create(user=user)
            profile_user.save()
            # login(request, user)
            messages.success(request, 'Регистрация прошла успешно. Войдите в аккаунт')
            return redirect('login')
        else:
            for field in form.errors:
                messages.error(request, form.errors[field].as_text())
            redirect('register')
    else:
        form = RegistrationForm()
    context = {
        'form': form,
        'title': 'Регистрация пользователя'
    }
    return render(request, 'blog/register.html', context)


class SearchResults(ArticleList):
    def get_queryset(self):
        word = self.request.GET.get('q')
        articles = Article.objects.filter(
            Q(title__icontains=word) | Q(content__icontains=word)
        )
        return articles


def save_comment(request, pk):
    form = CommentForm(data=request.POST)
    if form.is_valid():
        comment = form.save(commit=False)
        comment.article = Article.objects.get(pk=pk)
        comment.user = request.user
        comment.save()
        messages.success(request, 'Ваш комментарий добавлен')
        return redirect('article', pk)


def profile(request, user_id):
    user = User.objects.get(pk=user_id)
    profile_user = Profile.objects.get(user=user)
    context = {
        'profile': profile_user
    }
    return render(request, 'blog/profile.html', context)

def edit_profile(request):
    if request.method == 'POST':
        form1 = EditUserForm(data=request.POST)
        if form1.is_valid():
            user = request.user
            user.username = form1.cleaned_data['username']
            user.first_name = form1.cleaned_data['first_name']
            user.last_name = form1.cleaned_data['last_name']
            user.email = form1.cleaned_data['email']
            user.save()
        form2 = EditProfileForm(data=request.POST, instance=request.user)
        if form2.is_valid():
            profile_user = Profile.objects.get(user=request.user)
            profile_user.bio = form2.cleaned_data['bio']
            profile_user.phone = form2.cleaned_data['phone']
            profile_user.photo = form2.cleaned_data['photo']
            profile_user.save()
        user_id = request.user.pk
        return redirect('profile', user_id)

    else:
        form1 = EditUserForm(instance=request.user)
        form2 = EditProfileForm()

    context = {
        'form1': form1,
        'form2': form2
    }
    return render(request, 'blog/edit_account.html', context)


def add_or_delete_mark(request, article_id, action):
    user = request.user
    if user.is_authenticated:
        article = Article.objects.get(pk=article_id)
        mark, created = Like.objects.get_or_create(user=user, article=article)
        if action == 'add_like':
            mark.like = True
            mark.dislike = False
        elif action == 'add_dislike':
            mark.like = False
            mark.dislike = True
        elif action == 'delete_like':
            mark.like = False
        elif action == 'delete_dislike':
            mark.dislike = False
        mark.save()
        return redirect('article', article.pk)
    else:
        return redirect('login')



